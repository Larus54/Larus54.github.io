import Finestra.MyPanel;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        JFrame f = new JFrame("Bilancio");
        MyPanel p = new MyPanel();

        f.add(p);
        f.pack();
        f.setVisible(true);

    }
}
