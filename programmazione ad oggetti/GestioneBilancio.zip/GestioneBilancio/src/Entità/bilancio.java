package Entità;

public class bilancio {
    private String data;
    private String descrizione;
    private int ammontare;


    public bilancio(String data, String descrizione, int ammontare)
    {
        this.data = data;
        this.descrizione = descrizione;
        this.ammontare = ammontare;
    }


    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getAmmontare() {
        return ammontare;
    }

    public void setAmmontare(int ammontare) {
        this.ammontare = ammontare;
    }
}
