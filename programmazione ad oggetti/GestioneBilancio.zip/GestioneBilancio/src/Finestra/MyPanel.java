package Finestra;

import Entità.bilancio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Vector;

public class MyPanel extends JPanel {


    public MyPanel() {

        super();

        Vector v = new Vector(0);

        v.add(new bilancio("21/10/2020", "Pagamento regalo bibba", -500));

        JLabel lblammo = new JLabel("Ammontare");
        JLabel lbldesc = new JLabel("Descrizione della transazione");
        JLabel lbldata = new JLabel("Data della transazione");
        JTextField txtdata = new JTextField(20);
        JTextField txtdesc = new JTextField(20);
        JTextField txtammo = new JTextField(20);
        JButton btnInsert = new JButton("Inserisci");
        JButton btnSave = new JButton("Salva");
        JButton btnLoad = new JButton("Carica");
        JButton btnExport = new JButton("Esporta");


        MyTableModel f = new MyTableModel(v);
        JTable t = new JTable(f);

        t.setPreferredScrollableViewportSize(new Dimension(480, 70));
        t.setBackground(new Color(20, 40, 50));
        t.setForeground(Color.WHITE);
        t.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(t);
        
        //Blocca il bottone insert per evitare degli errori di inserimento
        btnInsert.setEnabled(txtammo.getText() != null|| txtdesc.getText() != "" || txtdata.getText() != "");


        //Ascoltatore che gestisce direttamente il bottone: Aggiunge un nuovo elemento
        //nella tabella e l'aggiorna automaticamente
        btnInsert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bilancio nuovo = new bilancio(txtdata.getText(), txtdesc.getText(), Integer.parseInt(txtammo.getText()));
                v.add(nuovo);
                f.fireTableDataChanged(); //Aggiorna la tabella
            }
        });

        //salvataggio in un file della table presente
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    FileOutputStream fos = new FileOutputStream("table.txt");
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    
                }
                catch (FileNotFoundException exception)
                {

                }
                catch(IOException exception)
                {

                }


            }
        });

        btnLoad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader("tabella.txt"));
                    String line = reader.readLine();
                    int j = 0;
                    while (line != null) {
                        String[] cells = line.split(",");
                        for (int i = 0; i < cells.length; i++) {
                            t.setValueAt(cells[i], j, i);
                        }
                        j++;
                    }

                    reader.close();


                }
                catch(IOException exception)
                {

                }
            }
        });

        //Inserimenti nel JPanel
        add(btnInsert);
        add(t);
        add(txtdata);
        add(txtammo);
        add(txtdesc);
        add(lbldata);
        add(lblammo);
        add(lbldesc);
    }
}
