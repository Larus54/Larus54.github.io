package Finestra;

import javax.swing.table.DefaultTableCellRenderer;

public class TableWithColors extends DefaultTableCellRenderer {
}
