package Finestra;

import Entità.bilancio;

import javax.swing.table.AbstractTableModel;
import java.util.Vector;

public class MyTableModel extends AbstractTableModel {

    private Vector v = null;
    private String[] colums = {"Data" , "Descrizione", "Ammontare"};


    MyTableModel(Vector v)
    {
        this.v = v;
    }

    @Override
    public int getRowCount() {
        return v.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        bilancio b = (bilancio) v.elementAt(rowIndex);

        switch (columnIndex) {
            case 0:
                return b.getData();
            case 1:
                return b.getDescrizione();
            case 2:
                return b.getAmmontare()+"€";
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int col)
    {
        return colums[col];
    }

    @Override
    public Class<?> getColumnClass(int col)
    {
        if(getValueAt(0, col) != null)
            return getValueAt(0, col).getClass();
        else
            return Object.class;

    }

    @Override
    public boolean isCellEditable(int row, int col)
    {
        return true;
    }

    public void setValueAt(Object value, int row, int col)
    {
        bilancio b = (bilancio)v.elementAt(row);
        if(col == 0)
            b.setData(value.toString()) ;
        if(col == 1)
            b.setDescrizione(value.toString());
        if(col == 2)
            b.setAmmontare(((Integer)value).intValue());

        fireTableDataChanged();

    }
}
